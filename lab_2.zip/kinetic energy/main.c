/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   #include <stdio.h>

int main() {
    float mass, velocity, kineticEnergy;

    // Input mass and velocity
    printf("Enter mass (kg): ");
    scanf("%f", &mass);

    printf("Enter velocity (m/s): ");
    scanf("%f", &velocity);

    // Calculate kinetic energy
    kineticEnergy = 0.5 * mass * velocity * velocity;

    // Display result
    printf("Kinetic Energy = %.2f Joules\n", kineticEnergy);

    return 0;
}

    return 0;
}
