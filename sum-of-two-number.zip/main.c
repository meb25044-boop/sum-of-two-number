/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    #include <stdio.h>

int main()
{
    float a,b,sum;
    printf("the value of a:");
    scanf("%f",&a);
    printf("the value of b:");
    scanf("%f",&b);
    sum=a+b;
    printf("the value of sum:%f",sum);

    return 0;
}


    return 0;
}
